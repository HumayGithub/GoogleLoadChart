﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using Chart.Models;

namespace Chart.Controllers
{
    public class HomeController : Controller
    {
        db GetDb = new db();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult Getdata()
        {
            DataSet ds = GetDb.GetView();
            List<Student> list = new List<Student>();
            foreach(DataRow dr in ds.Tables[0].Rows)
            {
                list.Add(new Student
                {
                    Name = Convert.ToString(dr["Name"]),
                    Score= Convert.ToInt32(dr["Score"])
            });
            }
            return Json(list, JsonRequestBehavior.AllowGet);
        }
    }
}